const cdn1map1 = a => {
	a = el({a:'div', b:a, d:{id:'cdn1map1'} });
	
	el({a:'img', b:a, d:{src:'a.png', style:'width:100%; height:100%;'}})
}
