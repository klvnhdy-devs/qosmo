const cdn1 = a => {
	a.innerHTML = ''
	
	cdn1map1(a)
	cdn1card1(a)
}