const cdn1card1 = a => {
	a = el({a:'div', b:a, d:{id:'cdn1card1'} });
	
}