const page1card4 = a => {
	a = el({a:'div', b:a, d:{id:'page1card4'} })
	
}
