const page1card7 = a => {
	a = el({a:'div', b:a, d:{id:'page1card7'} })
	
}
