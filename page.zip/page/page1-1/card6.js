const page1card6 = a => {
	a = el({a:'div', b:a, d:{id:'page1card6'} })
	
}
