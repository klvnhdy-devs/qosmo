const page1 = a => {
	a.innerHTML = ''
	
	//map1(a)
	page1card1(a)
	page1card2(a)
	page1card3(a)
	page1card4(a)
	page1card5(a)
	page1card6(a)
	page1card7(a)
}