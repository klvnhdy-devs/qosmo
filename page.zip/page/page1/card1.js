const page1card1 = a => {
	a = el({a:'div', b:a, c:'National Statistics', d:{id:'page1card1'} })
}
