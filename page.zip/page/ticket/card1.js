const ticket1card1 = a => {
	a = el({a:'div', b:a, d:{id:'ticket1card1'} });
	
}

const ticket1card2 = a => {
	a = el({a:'div', b:a, d:{id:'ticket1card2'} });
	
}

const ticket1card3 = a => {
	a = el({a:'div', b:a, d:{id:'ticket1card3'} });
	
}

const ticket1card4 = a => {
	a = el({a:'div', b:a, d:{id:'ticket1card4'} });
	
}
