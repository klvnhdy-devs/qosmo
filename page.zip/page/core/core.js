const core1 = a => {
	a.innerHTML = ''
	
	map1(a)
	core1card1(a)
	core1card2(a)
	core1card3(a)
	core1card4(a)
	core1card5(a)
	core1card6(a)
}