const core1card6 = a => {
	a = el({a:'div', b:a, d:{id:'core1card6'} })
	
}
