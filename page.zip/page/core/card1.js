const core1card1 = a => {
	a = el({a:'div', b:a, c:'National Statistics', d:{id:'core1card1'} })
}
