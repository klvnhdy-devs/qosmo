const core1card3 = a => {
	a = el({a:'div', b:a, d:{id:'core1card3'} })
	
}
