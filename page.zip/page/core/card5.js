const core1card5 = a => {
	a = el({a:'div', b:a, d:{id:'core1card5'} })
	
}
